<div>
    <?php echo e($idUsuario); ?>;
    <?php echo e($email); ?>;
</div>
<?php /**PATH C:\wamp64\www\resources\views/login.blade.php ENDPATH**/ ?>