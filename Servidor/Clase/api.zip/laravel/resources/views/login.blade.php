<div>
    {{$idUsuario}};
    {{$email}};
</div>
