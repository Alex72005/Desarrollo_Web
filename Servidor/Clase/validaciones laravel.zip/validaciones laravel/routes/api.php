<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventoController;
use App\Http\Controllers\EventoEtiquetaController;
use App\Http\Controllers\AsistenteController;
use App\Http\Controllers\DetalleEventoController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('/eventos', [EventoController::class, 'index']);
Route::post('/eventos', [EventoController::class, 'store']);
Route::put('/eventos/edit/{id}', [EventoController::class, 'update']);
Route::delete('/eventos/delete/{id}', [EventoController::class, 'destroy']);
Route::get('/eventos/show/{id}', [EventoController::class, 'show']);

/*1 a 1 */
Route::post('/detalle', [DetalleEventoController::class, 'store']);
Route::get('/detalle/{evento_id}', [DetalleEventoController::class, 'show']);
Route::put('/detalle/{evento_id}', [DetalleEventoController::class, 'update']);
Route::delete('/detalle/{evento_id}', [DetalleEventoController::class, 'destroy']);

/*1 a N */
Route::post('/asistente', [AsistenteController::class, 'store']);
Route::get('/asistente/{id}', [AsistenteController::class, 'show']);
Route::put('/asistente/{id}', [AsistenteController::class, 'update']);
Route::delete('/asistente/{id}', [AsistenteController::class, 'destroy']);

/*N a N*/
Route::post('/evento/etiqueta/add', [EventoEtiquetaController::class, 'addEtiqueta']);
Route::post('/evento/etiqueta/remove', [EventoEtiquetaController::class, 'removeEtiqueta']);
Route::get('/evento/{id}/etiquetas', [EventoEtiquetaController::class, 'getEtiquetas']);