<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class DetalleEvento extends Model
{
    use HasFactory; 
    protected $table = 'detalles_evento';
    protected $primaryKey = 'id';
    protected $fillable = [
        'evento_id',
        'aforo_maximo',
        'descripcion'
    ];

    public function evento()
    {
        return $this->belongsTo(Evento::class, 'evento_id', 'id');
    }
}
