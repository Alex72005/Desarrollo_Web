<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Etiqueta extends Model
{
    use HasFactory; 
    protected $table = 'etiquetas';
    protected $primaryKey = 'id';
    protected $fillable = ['nombre'];

    public function eventos()
    {
        return $this->belongsToMany(Evento::class, 'evento_etiqueta', 'etiqueta_id', 'evento_id');
    }
}
