<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    use HasFactory;

    protected $table = 'eventos';
    protected $primaryKey = 'id';
    protected $fillable = [
        'nombre',
        'ubicacion',
        'fecha',
        'hora_inicio',
        'hora_fin'
    ];

    public function detalle()
    {
        return $this->hasOne(DetalleEvento::class, 'evento_id', 'id');
    }

    public function asistentes()
    {
        return $this->hasMany(Asistente::class, 'evento_id', 'id');
    }

    public function etiquetas()
    {
        return $this->belongsToMany(Etiqueta::class, 'evento_etiqueta', 'evento_id', 'etiqueta_id');
    }
}
