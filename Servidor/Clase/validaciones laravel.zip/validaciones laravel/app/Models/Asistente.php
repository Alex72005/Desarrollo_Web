<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Asistente extends Model
{
    use HasFactory; 
    protected $table = 'asistentes';
    protected $primaryKey = 'id';
    protected $fillable = [
        'evento_id',
        'nombre',
        'email'
    ];

    public function evento()
    {
        return $this->belongsTo(Evento::class, 'evento_id', 'id');
    }
}
