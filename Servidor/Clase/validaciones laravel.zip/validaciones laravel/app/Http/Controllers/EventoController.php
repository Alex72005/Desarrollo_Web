<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Evento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EventoController extends Controller
{

    public static function validar()
    {
        $reglas = [
            'nombre' => 'required|string|min:3|max:10',
            'ubicacion' => 'nullable|string|min:3|max:100',
            'fecha' => 'required|date',
            'hora_inicio' => 'required',
            'hora_fin' => 'nullable'
        ];

        $mensajes = [
            'nombre.required' => 'El nombre es obligatorio',
            'nombre.min' => 'El nombre debe tener entre 3 y 10 caracteres',
            'nombre.max' => 'El nombre debe tener entre 3 y 10 caracteres',

            'fecha.required' => 'La fecha es obligatoria',
            'fecha.date' => 'La fecha debe ser válida',

            'hora_inicio.required' => 'La hora de inicio es obligatoria'
        ];

        return [$reglas, $mensajes];
    }

    /** 
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            if ((!isset($request['nombre'])) && (!isset($request['fechaInicio'])) && (!isset($request['fechaFin']))) {
                $evento = Evento::all();
                return response()->json($evento);
            } else if ((isset($request['nombre'])) && (!isset($request['fechaInicio'])) && (!isset($request['fechaFin']))) {
                $evento = Evento::where("nombre", $request['nombre'])->first();
                return response()->json($evento);
            } else if ((!isset($request['nombre'])) && (isset($request['fechaInicio'])) && (isset($request['fechaFin']))) {
                $evento = Evento::where("fecha", ">=", $request['fechaInicio'])->where("fecha", "<=", $request['fechaFin'])->get();
                return response()->json($evento);
            }
        } catch (Exception $e) {
            return response()->json([
                "error" => "No se mostraron todos los eventos",
                "mensaje" => $e->getMessage()
            ]);
        }
        // try {
        //     $eventos = Evento::all();
        //     return response()->json($eventos);
        // } catch (Exception $e) {
        //     return response()->json([
        //         "error" => "No se mostraron todos los eventos",
        //         "mensaje" => $e->getMessage()
        //     ]);
        // }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);
        try {
            if ($validacion->fails()) {
                return response()->json(["error" => $validacion->errors()->first()]);
            }

            $evento = new Evento();
            $evento->nombre = $request->nombre;
            $evento->ubicacion = $request->ubicacion;
            $evento->fecha = $request->fecha;
            $evento->hora_inicio = $request->hora_inicio;
            $evento->hora_fin = $request->hora_fin;

            $evento->save();

            return response()->json([
                "success" => "El evento se ha creado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "error" => "El evento no se ha creado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $evento = Evento::whereId($id)->first();
            return response()->json($evento);
        } catch (Exception $e) {
            return response()->json([
                "error" => "No se mostraron el evento buscado",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $evento = Evento::whereId($id)->first();
        if (!$evento) {
            return response()->json(['success' => 'el evento no existe']);
        }

        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);

        try {
            if ($validacion->fails()) {
                return response()->json(["error" => $validacion->errors()->first()]);
            }

            $evento->nombre = $request->nombre;
            $evento->ubicacion = $request->ubicacion;
            $evento->fecha = $request->fecha;
            $evento->hora_inicio = $request->hora_inicio;
            $evento->hora_fin = $request->  hora_fin;

            $evento->save();

            return response()->json([
                "success" => "El evento se ha actualizado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "error" => "El evento no se ha actualizado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $evento = Evento::whereId($id)->first();
            $evento->delete();
            return response()->json([
                "success" => "El evento se ha borrado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "success" => "El evento no se ha borrado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }
}
