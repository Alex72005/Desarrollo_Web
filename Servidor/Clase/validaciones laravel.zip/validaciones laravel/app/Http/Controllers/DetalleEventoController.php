<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Evento;
use App\Models\DetalleEvento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DetalleEventoController extends Controller
{
    //////////////////////// REGLAS ////////////////////////////

    public static function validar()
    {
        $reglas = [
            'evento_id'     => 'required|exists:eventos,id|unique:detalles_evento,evento_id',  //entre tablas
            'aforo_maximo'  => 'required|integer|min:1',
            'descripcion'   => 'nullable|string|max:500'
        ];

        $mensajes = [
            'evento_id.required' => 'Debe indicar el evento asociado',
            'evento_id.exists'   => 'El evento no existe',
            'evento_id.unique'   => 'Este evento ya tiene un detalle registrado',

            'aforo_maximo.required' => 'El aforo es obligatorio',
            'aforo_maximo.integer'  => 'El aforo debe ser numérico',
            'aforo_maximo.min'      => 'El aforo debe ser mayor a 0',
        ];

        return [$reglas, $mensajes];
    }

    //////////////////////// CREATE ////////////////////////////

    public function store(Request $request)
    {
        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);

        try {

            if ($validacion->fails()) {
                return response()->json(['error' => $validacion->errors()->first()]);
            }

            $detalle = new DetalleEvento();
            $detalle->evento_id = $request->evento_id;
            $detalle->aforo_maximo = $request->aforo_maximo;
            $detalle->descripcion = $request->descripcion;

            $detalle->save();

            return response()->json(['success' => 'El detalle del evento se ha creado correctamente']);
        } catch (Exception $e) {
            return response()->json([
                'error' => 'No se pudo crear el detalle del evento',
                'mensaje' => $e->getMessage()
            ]);
        }
    }

    //////////////////////// SHOW ////////////////////////////

    public function show(string $evento_id)
    {
        try {

            $detalle = DetalleEvento::where("evento_id", $evento_id)->first();

            if (!$detalle) {
                return response()->json(['error' => 'Este evento no tiene detalle asociado']);
            }

            return response()->json($detalle);
        } catch (Exception $e) {
            return response()->json([
                'error' => 'No se pudo obtener el detalle del evento',
                'mensaje' => $e->getMessage()
            ]);
        }
    }

    //////////////////////// UPDATE ////////////////////////////

    public function update(Request $request, string $evento_id)
    {
        $detalle = DetalleEvento::where("evento_id", $evento_id)->first();

        if (!$detalle) {
            return response()->json(['error' => 'El detalle del evento no existe']);
        }

        $reglas = [
            'aforo_maximo' => 'required|integer|min:1',
            'descripcion'  => 'nullable|string|max:500'
        ];

        $mensajes = [
            'aforo_maximo.required' => 'El aforo es obligatorio',
            'aforo_maximo.integer'  => 'El aforo debe ser entero',
            'aforo_maximo.min'      => 'El aforo debe ser mayor que 0'
        ];

        // En update NO se valida evento_id porque no se cambia
        $validacion = Validator::make($request->all(), $reglas, $mensajes);

        try {

            if ($validacion->fails()) {
                return response()->json(['error' => $validacion->errors()->first()]);
            }

            $detalle->aforo_maximo = $request->aforo_maximo;
            $detalle->descripcion = $request->descripcion;

            $detalle->save();

            return response()->json(['success' => 'El detalle del evento se ha actualizado correctamente']);
        } catch (Exception $e) {
            return response()->json([
                'error' => 'No se pudo actualizar el detalle del evento',
                'mensaje' => $e->getMessage()
            ]);
        }
    }

    //////////////////////// DELETE ////////////////////////////

    public function destroy(string $evento_id)
    {
        try {

            $detalle = DetalleEvento::where("evento_id", $evento_id)->first();

            if (!$detalle) {
                return response()->json(['error' => 'El detalle del evento no existe']);
            }

            $detalle->delete();

            return response()->json(['success' => 'El detalle del evento se ha borrado correctamente']);
        } catch (Exception $e) {
            return response()->json([
                'error' => 'No se pudo borrar el detalle del evento',
                'mensaje' => $e->getMessage()
            ]);
        }
    }
}
