<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Evento;
use App\Models\Etiqueta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class EventoEtiquetaController extends Controller
{
    public static function validar()
    {
        $reglas = [
            'evento_id'   => 'required|exists:eventos,id',
            'etiqueta_id' => 'required|exists:etiquetas,id'
        ];

        $mensajes = [
            'evento_id.required' => 'Debe indicar el evento',
            'evento_id.exists'   => 'El evento no existe',

            'etiqueta_id.required' => 'Debe indicar la etiqueta',
            'etiqueta_id.exists'   => 'La etiqueta no existe',
        ];

        return [$reglas, $mensajes];
    }

    // Añadir etiqueta a evento (INSERT en la tabla pivote)
    public function addEtiqueta(Request $request)
    {
        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);

        try {
            if ($validacion->fails()) {
                return response()->json(['error' => $validacion->errors()->first()]);
            }

            // Validación entre tablas:
            // evitar duplicados en la tabla pivote
            $yaExiste = DB::table('evento_etiqueta')
                ->where('evento_id', $request->evento_id)
                ->where('etiqueta_id', $request->etiqueta_id)
                ->exists();

            if ($yaExiste) {
                return response()->json(['error' => 'Este evento ya tiene esa etiqueta']);
            }

            DB::table('evento_etiqueta')->insert([
                'evento_id' => $request->evento_id,
                'etiqueta_id' => $request->etiqueta_id
            ]);

            return response()->json(['success' => 'Etiqueta añadida al evento']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    // Mostrar todas las etiquetas del evento
    public function getEtiquetas($evento_id)
    {
        try {
            $evento = Evento::whereId($evento_id)->first();

            if (!$evento) {
                return response()->json(['error' => 'El evento no existe']);
            }

            return response()->json($evento->etiquetas);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    // Quitar una etiqueta de un evento (DELETE)
    public function removeEtiqueta(Request $request)
    {
        try {
            DB::table('evento_etiqueta')
                ->where('evento_id', $request->evento_id)
                ->where('etiqueta_id', $request->etiqueta_id)
                ->delete();

            return response()->json(['success' => 'Etiqueta eliminada del evento']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }
}
