<?php

namespace App\Http\Controllers;

use App\Models\Evento;
use Exception;
use Illuminate\Http\Request;

class Evento2Controller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            if ((!isset($request['nombre'])) && (!isset($request['fechaInicio'])) && (!isset($request['fechaFin']))) {
                $evento = Evento::all();
                return response()->json($evento);
            } else if ((isset($request['nombre'])) && (!isset($request['fechaInicio'])) && (!isset($request['fechaFin']))) {
                $evento = Evento::where("nombre", $request['nombre'])->first();
                return response()->json($evento);
            } else if ((!isset($request['nombre'])) && (isset($request['fechaInicio'])) && (isset($request['fechaFin']))) {
                $evento = Evento::where("fecha", ">=", $request['fechaInicio'])->where("fecha", "<=", $request['fechaFin'])->get();
                return response()->json($evento);
            }
        } catch (Exception $e) {
            return response()->json([
                "error" => "No se mostraron todos los eventos",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate(
            [
                'nombre' => [
                    'required',
                    'string',
                    'min:3',
                    'max:30',
                    'regex:/^[a-zA-ZÁÉÍÓÚÑáéíóúñ\s]+$/'
                ],
                'ubicacion' => [
                    'required',
                    'string',
                    'min:3',
                    'max:50',
                    'regex:/^[a-zA-ZÁÉÍÓÚÑáéíóúñ\s]+$/'
                ],
                'fecha' => [
                    'required',
                    'date',
                    'after_or_equal:today'
                ],
                'hora' => [
                    'required',
                    'date_format:H:i'
                ],
            ],
            [
                // MENSAJES PERSONALIZADOS
                'nombre.required' => 'El nombre es obligatorio',
                'nombre.min' => 'El nombre debe tener al menos 3 caracteres',
                'nombre.max' => 'El nombre no puede superar los 30 caracteres',
                'nombre.regex' => 'El nombre solo puede contener letras',

                'ubicacion.required' => 'La ubicación es obligatoria',
                'ubicacion.min' => 'La ubicación debe tener al menos 3 caracteres',
                'ubicacion.max' => 'La ubicación no puede superar los 50 caracteres',
                'ubicacion.regex' => 'La ubicación solo puede contener letras',

                'fecha.required' => 'La fecha es obligatoria',
                'fecha.date' => 'Formato de fecha inválido',
                'fecha.after_or_equal' => 'La fecha no puede ser anterior a hoy',

                'hora.required' => 'La hora es obligatoria',
                'hora.date_format' => 'Formato de hora inválido (HH:MM)',
            ]
        );

        try {
            $evento = Evento::create($request->only(['nombre', 'ubicacion', 'fecha', 'hora']));

            return response()->json([
                "success" => "El evento se ha creado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "error" => "El evento no se ha creado correctamente",
                "mensaje" => $e->getMessage()
            ], 400);
        }
    }

    // public function store(Request $request)
    // {
    //     try {
    //         $nombre = $request['nombre'];
    //         $ubicacion = $request['ubicacion'];
    //         $fecha = $request['fecha'];
    //         $hora = $request['hora'];

    //         $evento = new Evento();
    //         $evento->nombre = $nombre;
    //         $evento->ubicacion = $ubicacion;
    //         $evento->fecha = $fecha;
    //         $evento->hora = $hora;

    //         $evento->save();

    //         return response()->json([
    //             "success" => "El evento se ha creado correctamente"
    //         ]);
    //     } catch (Exception $e) {
    //         return response()->json([
    //             "error" => "El evento no se ha creado correctamente",
    //             "mensaje" => $e->getMessage()
    //         ]);
    //     }
    // }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $evento = Evento::whereId($id)->first();
            return response()->json($evento);
        } catch (Exception $e) {
            return response()->json([
                "error" => "No se mostraron el evento buscado",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate(
            [
                'nombre' => [
                    'required',
                    'string',
                    'min:3',
                    'max:30',
                    'regex:/^[a-zA-ZÁÉÍÓÚÑáéíóúñ\s]+$/'
                ],
                'ubicacion' => [
                    'required',
                    'string',
                    'min:3',
                    'max:50',
                    'regex:/^[a-zA-ZÁÉÍÓÚÑáéíóúñ\s]+$/'
                ],
                'fecha' => [
                    'required',
                    'date',
                    'after_or_equal:today'
                ],
                'hora' => [
                    'required',
                    'date_format:H:i'
                ]
            ],
            [
                'nombre.required' => 'El nombre es obligatorio',
                'nombre.min' => 'El nombre debe tener al menos 3 caracteres',
                'nombre.max' => 'El nombre no puede superar los 30 caracteres',
                'nombre.regex' => 'El nombre solo puede contener letras',

                'ubicacion.required' => 'La ubicación es obligatoria',
                'ubicacion.min' => 'La ubicación debe tener al menos 3 caracteres',
                'ubicacion.max' => 'La ubicación no puede superar los 50 caracteres',
                'ubicacion.regex' => 'La ubicación solo puede contener letras',

                'fecha.required' => 'La fecha es obligatoria',
                'fecha.date' => 'Formato de fecha inválido',
                'fecha.after_or_equal' => 'La fecha no puede ser anterior a hoy',

                'hora.required' => 'La hora es obligatoria',    
                'hora.date_format' => 'Formato de hora inválido (HH:MM)',
            ]
        );
        try {
            $evento = Evento::whereId($id)->first();
            $evento->update($request->only(['nombre', 'ubicacion', 'fecha', 'hora']));

            return response()->json([
                "success" => "El evento se ha actualizado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "error" => "El evento no se ha actualizado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    // public function update(Request $request, string $id)
    // {
    //     try {
    //         $nombre = $request['nombre'];
    //         $ubicacion = $request['ubicacion'];
    //         $fecha = $request['fecha'];
    //         $hora = $request['hora'];

    //         $evento = Evento::whereId($id)->first();
    //         $evento->nombre = $nombre;
    //         $evento->ubicacion = $ubicacion;
    //         $evento->fecha = $fecha;
    //         $evento->hora = $hora;

    //         $evento->save();

    //         return response()->json([
    //             "success" => "El evento se ha actualizado correctamente"
    //         ]);
    //     } catch (Exception $e) {
    //         return response()->json([
    //             "error" => "El evento no se ha actualizado correctamente",
    //             "mensaje" => $e->getMessage()
    //         ]);
    //     }
    // }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $evento = Evento::whereId($id)->first();
            $evento->delete();
            return response()->json([
                "success" => "El evento se ha borrado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "success" => "El evento no se ha borrado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }
}
