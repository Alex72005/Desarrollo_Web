<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Asistente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AsistenteController extends Controller
{
    //////////////////////// REGLAS ////////////////////////////

    public static function validar()
    {
        $reglas = [
            'evento_id'  => 'required|exists:eventos,id',
            'nombre'     => 'required|string|min:3|max:50',
            'email'      => 'nullable|email|max:100'
        ];

        $mensajes = [
            'evento_id.required' => 'Debe indicar el evento',
            'evento_id.exists'   => 'El evento no existe',

            'nombre.required' => 'El nombre es obligatorio',
            'nombre.min'      => 'El nombre debe tener mínimo 3 caracteres',

            'email.email' => 'Debe ser un email válido',
        ];

        return [$reglas, $mensajes];
    }

    //////////////////////// CREATE ////////////////////////////

    public function store(Request $request)
    {
        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);

        try {

            if ($validacion->fails()) {
                return response()->json(['error' => $validacion->errors()->first()]);
            }

            // Validación entre tablas:
            // NO permitir nombres duplicados en el mismo evento
            $existe = Asistente::where('evento_id', $request->evento_id)
                ->where('nombre', $request->nombre)
                ->exists();

            if ($existe) {
                return response()->json(['error' => 'Ese asistente ya está registrado en este evento']);
            }

            $asistente = new Asistente();
            $asistente->evento_id = $request->evento_id;
            $asistente->nombre    = $request->nombre;
            $asistente->email     = $request->email;

            $asistente->save();

            return response()->json(['success' => 'El asistente se ha registrado correctamente']);
        } catch (Exception $e) {
            return response()->json([
                'error' => 'No se pudo registrar el asistente',
                'mensaje' => $e->getMessage()
            ]);
        }
    }

    //////////////////////// SHOW ////////////////////////////

    public function show(string $id)
    {
        try {
            $asistente = Asistente::find($id);

            if (!$asistente) {
                return response()->json(['error' => 'El asistente no existe']);
            }

            return response()->json($asistente);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    //////////////////////// UPDATE ////////////////////////////

    public function update(Request $request, string $id)    
    {
        $asistente = Asistente::whereId($id)->first();

        if (!$asistente) {
            return response()->json(['error' => 'El asistente no existe']);
        }

        $reglas = [
            'nombre' => 'required|string|min:3|max:50',
            'email'  => 'nullable|email|max:100'
        ];

        $mensajes = [
            'nombre.required' => 'El nombre es obligatorio',
            'email.email'     => 'El email debe ser válido'
        ];

        $validacion = Validator::make($request->all(), $reglas, $mensajes);

        try {
            if ($validacion->fails()) {
                return response()->json(['error' => $validacion->errors()->first()]);
            }

            // Validación entre tablas:
            // No duplicar asistente en el mismo evento
            $duplicado = Asistente::where('evento_id', $asistente->evento_id)
                ->where('nombre', $request->nombre)
                ->where('id', '!=', $asistente->id)
                ->exists();

            if ($duplicado) {
                return response()->json(['error' => 'Ya existe un asistente con ese nombre en este evento']);
            }

            $asistente->nombre = $request->nombre;
            $asistente->email  = $request->email;

            $asistente->save();

            return response()->json(['success' => 'El asistente se ha actualizado correctamente']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    //////////////////////// DELETE ////////////////////////////

    public function destroy(string $id)
    {
        try {
            $asistente = Asistente::find($id);

            if (!$asistente) {
                return response()->json(['error' => 'El asistente no existe']);
            }

            $asistente->delete();

            return response()->json(['success' => 'El asistente se ha eliminado correctamente']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }
}
