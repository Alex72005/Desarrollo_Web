<?php

namespace Database\Seeders;

use App\Models\Evento;
use App\Models\DetalleEvento;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class DetalleEventoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $eventos = Evento::all();

        foreach ($eventos as $evento) {
            DetalleEvento::factory()->create([
                'evento_id' => $evento->id
            ]);
        }
    }
}
