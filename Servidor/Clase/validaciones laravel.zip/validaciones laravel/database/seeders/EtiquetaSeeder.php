<?php

namespace Database\Seeders;

use App\Models\Evento;
use App\Models\Etiqueta;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class EtiquetaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Etiqueta::factory(10)->create();

        $eventos = Evento::all();
        $etiquetas = Etiqueta::all();

        foreach ($eventos as $evento) {
            $evento->etiquetas()->attach(
                $etiquetas->random(rand(1, 3))->pluck('id')->toArray()
            );
        }
    }
}
