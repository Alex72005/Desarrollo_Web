<?php

namespace Database\Seeders;

use App\Models\Evento;
use App\Models\Asistente;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class AsistenteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $eventos = Evento::all();

        foreach ($eventos as $evento) {
            Asistente::factory(rand(3, 8))->create([
                'evento_id' => $evento->id
            ]);
        }
    }
}
