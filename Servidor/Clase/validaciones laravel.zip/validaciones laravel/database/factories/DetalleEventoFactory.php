<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\DetalleEvento>
 */
class DetalleEventoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */

    public function definition(): array
    {
        return [
            'evento_id' => null,  // lo asignarás en el seeder
            'aforo_maximo' => fake()->numberBetween(20, 300),
            'descripcion' => fake()->sentence(15)
        ];
    }
}
