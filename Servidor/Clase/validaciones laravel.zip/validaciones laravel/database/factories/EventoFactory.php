<?php

namespace Database\Factories;

use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Evento>
 */
class EventoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $hora = fake()->time('H:i');

        return [
            "nombre" => substr(fake()->word(), 0, 10),
            "ubicacion" => fake()->city(),
            "fecha" => fake()->date(),
            "hora_inicio" => $hora,
            "hora_fin" => Carbon::parse($hora)->addHour() //parseo la hora a su formato y le añado una hora
        ];
    }
}
