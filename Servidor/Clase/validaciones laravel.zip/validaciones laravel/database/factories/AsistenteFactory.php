<?php

namespace Database\Factories;

use App\Models\Evento;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Asistente>
 */
class AsistenteFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $evento = Evento::inRandomOrder()->first();

        return [
            'evento_id' => $evento ? $evento->id : Evento::factory()->create()->id,
            'nombre'    => fake()->name(),
            'email'     => fake()->safeEmail()
        ];
    }
}
