document.addEventListener('DOMContentLoaded', () => {
    const enrique= document.querySelector("enrique")
    console.log("me llamo sdkflñksdflñkñldsfk")
})