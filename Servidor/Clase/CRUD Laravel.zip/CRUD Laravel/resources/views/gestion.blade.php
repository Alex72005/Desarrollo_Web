<div>
    @foreach ($bandas as $b)
        {{$b->banda->nombre}}<br>
    @endforeach
</div>