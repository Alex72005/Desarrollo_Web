<form action="{{route("datos")}}" method="POST">
    @csrf
    <input name="email" type="text">
    <input name="password" type="password">
    <button type="sumbit">Enviar</button>
</form>

<div>
    @foreach ($centros as $c)
        <p>{{$c->nombre}}</p>
        <p>{{$c->pepito->nombre}}</p>
    @endforeach
</div>


