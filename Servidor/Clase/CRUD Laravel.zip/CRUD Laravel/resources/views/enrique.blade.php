<div id="enrique">
    {{$password}}
    {{$email}}
</div>

@vite("resources/js/prueba.js")
