<div>
    @foreach ($jugadores as $j)
        {{$j->nombre}}<br>
    @endforeach
</div>