<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Centro;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::factory(100)->create();

        /*User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);*/

        $this->call(TipoSeeder::class);
        $this->call(CentroSeeder::class);
        Centro::factory(100)->create();

        $this->call(HermandadSeeder::class);
        $this->call(BandaSeeder::class);
        $this->call(Hermandad_bandaSeeder::class);

        $this->call(EquipoSeeder::class);
        $this->call(JugadorSeeder::class);
    }
}
