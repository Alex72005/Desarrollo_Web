<?php

namespace Database\Seeders;

use App\Models\Jugador;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class JugadorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $jugador = new Jugador();
        $jugador->id = 1;
        $jugador->id_equipo = 1;
        $jugador->nombre = "Mbappe";
        $jugador->posicion = "delantero";
        $jugador->save();

        $jugador = new Jugador();
        $jugador->id = 2;
        $jugador->id_equipo = 1;
        $jugador->nombre = "Vini";
        $jugador->posicion = "delantero";
        $jugador->save();

        $jugador = new Jugador();
        $jugador->id = 3;
        $jugador->id_equipo = 2;
        $jugador->nombre = "Pedri";
        $jugador->posicion = "centrocampista";
        $jugador->save();

        $jugador = new Jugador();
        $jugador->id = 4;
        $jugador->id_equipo = 2;
        $jugador->nombre = "De Jong";
        $jugador->posicion = "centrocampista";
        $jugador->save();

        Jugador::factory(2)->create();
    }
}
