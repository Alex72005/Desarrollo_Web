<?php

namespace Database\Seeders;

use App\Models\Tipo;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class TipoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $tipo = new Tipo();
        $tipo->id = 1;
        $tipo->nombre = "FP";
        $tipo->save();

        $tipo = new Tipo();
        $tipo->id = 2;
        $tipo->nombre = "UCO";
        $tipo->save();

        $tipo = new Tipo();
        $tipo->id = 3;
        $tipo->nombre = "BACHILLERATO";
        $tipo->save();
    }
}
