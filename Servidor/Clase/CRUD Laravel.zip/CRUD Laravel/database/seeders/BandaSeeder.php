<?php

namespace Database\Seeders;

use App\Models\Banda;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class BandaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $banda = new Banda();
        $banda->id=1;
        $banda->nombre="Banda Cristo de Gracia";
        $banda->save();

        $banda = new Banda();
        $banda->id=2;
        $banda->nombre="Banda Salud";
        $banda->save();

        $banda = new Banda();
        $banda->id=3;
        $banda->nombre="Banda Coronación de Espinas";
        $banda->save();
    }
}
