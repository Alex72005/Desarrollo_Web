<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        body{
            margin: 50px
        }
    </style>
</head>

<body>
    <div class="w-full max-w-xs">
        <h1>Crear Hermandad</h1>
        <form action="<?php echo e(route("hermandad_crear")); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?> 
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Nombre
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="text" placeholder="Hermandad" name="nombre">
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Crear
                </button>
            </div>
        </form>
    </div>

    <br><br>

    <div class="w-full max-w-xs">
        <h1>Borrar Hermandad</h1>
        <form action="<?php echo e(route("hermandad_borrar")); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field("DELETE"); ?> 
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    <select name="hermandades" id="">
                        <?php $__currentLoopData = $hermandades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($h->id); ?>"><?php echo e($h->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </label>
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Borrar
                </button>
            </div>
        </form>
    </div>

    <br><br>

    <div class="w-full max-w-xs">
        <h1>Editar Hermandad</h1>
        <form action="<?php echo e(route("hermandad_editar")); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?> 
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    <select name="hermandades" id="">
                        <?php $__currentLoopData = $hermandades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($h->id); ?>"><?php echo e($h->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </label>
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Editar
                </button>
            </div>
        </form>
    </div>

    <br><br>

    <div class="w-full max-w-xs">
        <h1>Bandas de una Hermandad</h1>
        <form action="<?php echo e(route("bandas")); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    <select name="hermandades" id="">
                        <?php $__currentLoopData = $hermandades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($h->id); ?>"><?php echo e($h->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select>
                </label>
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Buscar
                </button>
            </div>
        </form>
    </div>

    <div class="flex space-x-4 mb-4" style="margin: 40px;">
        <form action="<?php echo e(route('hermandad_orden_asc')); ?>" method="GET">
            <button type="submit"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                Ordenar A → Z
            </button>
        </form>

        <form action="<?php echo e(route('hermandad_orden_desc')); ?>" method="GET">
            <button type="submit"
                class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                Ordenar Z → A
            </button>
        </form>
    </div>
    
    <table class="table-auto border-collapse border border-gray-400">
        <b style="margin: 40px">Hermandades</b>
        <tbody>
             <?php $__currentLoopData = $hermandades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <option value="<?php echo e($h->id); ?>"><?php echo e($h->nombre); ?></option>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <br><br>

    <div class="w-full max-w-xs">
        <h1>Filtrar por letra</h1>
        <form action="<?php echo e(route("hermandad_filtrar_letra")); ?>" method="GET" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?> 
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Nombre
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="text" placeholder="Hermandad" name="letra">
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Filtrar
                </button>
            </div>
        </form>
    </div>

    <table class="table-auto">
        <b style="margin: 40px">Filtro</b>
        <tbody>
             <?php $__currentLoopData = $hermandad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <option value="<?php echo e($h->id); ?>"><?php echo e($h->nombre); ?></option>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br><br>
    <div class="w-full max-w-xs">
        <h1>Buscar Hermandad</h1>
        <form action="<?php echo e(route("hermandad_buscar")); ?>" method="GET" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?> 
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Hermandad
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="text" placeholder="Hermandad" name="texto">
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Buscar
                </button>
            </div>
        </form>
    </div>

    <table class="table-auto">
        <b style="margin: 40px">Filtro</b>
        <tbody>
             <?php $__currentLoopData = $hermandad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <option value="<?php echo e($h->id); ?>"><?php echo e($h->nombre); ?></option>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\resources\views/prueba.blade.php ENDPATH**/ ?>