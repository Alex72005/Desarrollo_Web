<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AccionController;
use App\Http\Controllers\CentroController;
use App\Http\Controllers\EquipoController;
use App\Http\Controllers\EnriqueController;
use App\Http\Controllers\HermandadController;
use App\Http\Controllers\HermandadBandaController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/centros', [CentroController::class, "index"]);
Route::post('/mesa', [EnriqueController::class, "index"])->name("datos");

Route::post('/bandas', [HermandadBandaController::class, "bandasPorHermandad"])->name("bandas");
Route::get('/prueba', [HermandadController::class, "index"])->name("hermandad_mostrar");
Route::post('/hermandad', [HermandadController::class, "create"])->name("hermandad_crear");
Route::delete('/hermandad', [HermandadController::class, "destroy"])->name("hermandad_borrar");
Route::put('/hermandad', [HermandadController::class, "edit"])->name("hermandad_editar");
Route::put('/hermandad/actualizar', [HermandadController::class, "update"])->name("hermandad_actualizar");
Route::get('/hermandad/filtrarletra', [HermandadController::class, "filtrarPorLetra"])->name("hermandad_filtrar_letra");
Route::get('/hermandad/ordenAsc', [HermandadController::class, "ordenarAsc"])->name("hermandad_orden_asc");
Route::get('/hermandad/ordenDesc', [HermandadController::class, "ordenarDesc"])->name("hermandad_orden_desc");
Route::get('/hermandad/buscar', [HermandadController::class, "buscar"])->name("hermandad_buscar");

Route::get('/metodos', function () {
    return view('metodos');
});

Route::get('/accion', [AccionController::class, "index"])->name("accion");
Route::post('/accion', [AccionController::class, "create"])->name("accion");
Route::put('/accion', [AccionController::class, "update"])->name("accion");
Route::delete('/accion', [AccionController::class, "destroy"])->name("accion");


Route::get('/hola', [EquipoController::class, "index"])->name("equipo_mostrar");
Route::post('/equipo', [EquipoController::class, "create"])->name("equipo_crear");
Route::put('/equipo', [EquipoController::class, "edit"])->name("equipo_editar");
Route::put('/equipo/actualizar', [EquipoController::class, "update"])->name("equipo_actualizar");
Route::delete('/equipo', [EquipoController::class, "destroy"])->name("equipo_borrar");
Route::post('/jugadores', [EquipoController::class, "players"])->name("jugadores_equipo");