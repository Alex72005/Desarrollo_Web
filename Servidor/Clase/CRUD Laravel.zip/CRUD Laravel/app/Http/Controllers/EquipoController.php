<?php

namespace App\Http\Controllers;

use App\Models\Equipo;
use Illuminate\Http\Request;

class EquipoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $equipos = Equipo::all();
        return view("hola", ["equipos" => $equipos]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $e = new Equipo();
        $e->nombre = $request['nombre'];
        $e->save();

        return redirect()->route("equipo_mostrar");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        $idEquipo = $request["equipos"];
        $datosEquipo = Equipo::where("id", $idEquipo)->first();
        return view("editarEquipo", ["equipo" => $datosEquipo]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $equipoAActualizar = Equipo::where("id", $request["id"])->first();
        $equipoAActualizar->nombre = $request["nombre"];
        $equipoAActualizar->save();

        return redirect()->route("equipo_mostrar");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $equipoABorrar = Equipo::where("id", $request["equipos"])->delete();
        return redirect()->route("equipo_mostrar");
    }

    public function players(Request $request)
    {
        $idEquipo = $request["equipos"];
        $equipo = Equipo::where("id", $idEquipo)->first();
        $jugadores = $equipo->jugadores;
        return view("jugadores", ["jugadores" => $jugadores]);
    }
}
