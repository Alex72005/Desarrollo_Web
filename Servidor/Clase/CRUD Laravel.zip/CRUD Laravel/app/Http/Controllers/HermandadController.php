<?php

namespace App\Http\Controllers;

use App\Models\Hermandad;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class HermandadController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $hermandades = Hermandad::all();
        return view("prueba", ["hermandades" => $hermandades, "hermandad" => []]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $h = new Hermandad();
        $h->nombre = $request["nombre"];
        $h->save();

        return redirect()->route("hermandad_mostrar");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        $idHermandad = $request["hermandades"];
        $datosHermandad = Hermandad::where("id", $idHermandad)->first();
        return view("editarHermandad", ["hermandad" => $datosHermandad]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $hermandadAActualizar = Hermandad::where("id", $request["id"])->first();
        $hermandadAActualizar->nombre = $request["nombre"];
        $hermandadAActualizar->save();

        return redirect()->route("hermandad_mostrar");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $hermandadABorrar = Hermandad::where("id", $request["hermandades"])->delete();
        return redirect()->route("hermandad_mostrar");
    }

    public function filtrarPorLetra(Request $request)
    {
        $letra = $request['letra'];
        $hermandad = DB::table('hermandades')->where('nombre', 'like', $letra . '%')->get();
        $hermandades = Hermandad::all();
        return view('prueba', ['hermandad' => $hermandad, 'hermandades' => $hermandades]);
    }

    public function ordenarAsc()
    {
        $hermandades = DB::table('hermandades')->orderBy('nombre', 'asc')->get();
        return view('prueba', ['hermandades' => $hermandades, 'hermandad' => []]);
    }

    public function ordenarDesc()
    {
        $hermandades = DB::table('hermandades')->orderBy('nombre', 'desc')->get();
        return view('prueba', ['hermandades' => $hermandades, 'hermandad' => []]);
    }

    public function buscar(Request $request)
    {
        $texto = $request['texto'];
        $hermandades = Hermandad::all();
        $hermandad = DB::table('hermandades')
            ->where('nombre', 'like', '%' . $texto . '%')
            ->get();

        return view('prueba', ['hermandad' => $hermandad, 'hermandades' => $hermandades]);
    }
}
