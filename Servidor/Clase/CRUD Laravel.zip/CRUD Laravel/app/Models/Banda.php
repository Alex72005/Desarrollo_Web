<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Banda extends Model
{
    protected $table = "bandas";
    protected $primaryKey = "id";
    protected $fillable = ["nombre"];

    function hermandades(){
        return $this->hasMany(Hermandad_banda::class, "id_banda", "id");
    }
}
