<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Centro extends Model
{
    use HasFactory;

    protected $table = "centros";
    protected $primaryKey = "id";

    protected $fillable = [
        "nombre",
        "idTipo"
    ];

    public function pepito()
    {
        return $this->belongsTo('App\Models\Tipo', "idTipo", "id");
    }

}
