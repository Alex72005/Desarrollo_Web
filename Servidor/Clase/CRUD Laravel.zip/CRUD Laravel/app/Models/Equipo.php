<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Equipo extends Model
{
    use HasFactory;

    protected $table = "equipos";
    protected $primaryKey = "id";
    protected $fillable = ["nombre"];


    public function jugadores()
    {
        return $this->hasMany(Jugador::class, "id_equipo", "id");
    }
}
