<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Jugador extends Model
{
    use HasFactory;

    protected $table = "jugadores";
    protected $primaryKey = "id";
    protected $fillable = [
        "nombre",
        "posicion",
        "id_equipo"
    ];

    public function equipo()
    {
        return $this->belongsTo(Equipo::class, "id_equipo", "id");
    }
}
