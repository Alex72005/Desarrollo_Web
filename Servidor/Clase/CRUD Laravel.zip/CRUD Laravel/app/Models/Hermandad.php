<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hermandad extends Model
{
    protected $table = "hermandades";
    protected $primaryKey = "id";
    protected $fillable = ["nombre"];

    function bandas(){
        return $this->hasMany(Hermandad_banda::class, "id_hermandad", "id");
    }

}
