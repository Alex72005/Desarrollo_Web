<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class FormularioController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('formulario');
    }

    public function ejercicios(Request $request)
    {
        $numero = $request['numero'];
        $fecha = $request['fecha'];
        $cantidad = $request['cantidad'];
        $email = $request['email'];
        $password = $request['password'];

        if ($numero != null && $numero != '') {
            if ($this->esPrimo((int)$numero)) {
                $textoPrimo = "El número $numero es primo";
            } else {
                $textoPrimo = "El número $numero no es primo";
            }
        } else {
            $textoPrimo = null;
        }

        if ($fecha != null && $fecha != '') {
            if ($this->esBisiesto($fecha)) {
                $textoBisiesto = "El año de la fecha $fecha es bisiesto";
            } else {
                $textoBisiesto = "El año de la fecha $fecha no es bisiesto";
            }
        } else {
            $textoBisiesto = null;
        }

        if ($cantidad != null && $cantidad != '') {
            $serie = $this->fibonacci((int)$cantidad);
            $textoFibonacci = "Serie Fibonacci: ";
            foreach ($serie as $numero) {
                $textoFibonacci .= $numero . ' ';
            }
        } else {
            $textoFibonacci = null;
        }

        if ($email && $password) {
            if ($this->existeUsuario($email, $password)) {
                $textoUsuario = "El usuario existe";
            } else {
                $textoUsuario = "El usuario no existe";
            }
        } else {
            $textoUsuario = null;
        }

        return view('resultados', compact('textoPrimo', 'textoBisiesto', 'textoFibonacci', 'textoUsuario'));
    }

    private function esPrimo(int $numero)
    {
        if ($numero < 2) {
            return false;
        }

        for ($i = 2; $i <= sqrt($numero); $i++) {
            if ($numero % $i == 0) {
                return false;
            }
        }

        return true;
    }

    private function esBisiesto(string $fecha)
    {
        $anio = (int)substr($fecha, 6, 4);
        if ($anio % 4 == 0 && ($anio % 100 != 0 || $anio % 400 == 0)) {
            return true;
        }
        return false;
    }

    private function fibonacci(int $cantidad = 10)
    {
        $serie = [];

        for ($i = 0; $i < $cantidad; $i++) {
            if ($i == 0) $serie[] = 0;
            elseif ($i == 1) $serie[] = 1;
            else $serie[] = $serie[$i - 1] + $serie[$i - 2];
        }

        return $serie;
    }

    private function existeUsuario(string $email, string $password): bool
    {
        $usuario = DB::table('users')
            ->where('email', $email)
            ->where('password', $password)
            ->first();

        return $usuario != null;
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
