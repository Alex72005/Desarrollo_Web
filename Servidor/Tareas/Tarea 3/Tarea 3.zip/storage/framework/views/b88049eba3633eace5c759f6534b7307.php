<div>
    <form action="<?php echo e(route("e1")); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Número: </label>
    <input type="number" name="numeroprimo">
    <input type="submit" name="boton">
</form>
</div>
<?php /**PATH C:\wamp64\www\resources\views/formularioejercicio1.blade.php ENDPATH**/ ?>