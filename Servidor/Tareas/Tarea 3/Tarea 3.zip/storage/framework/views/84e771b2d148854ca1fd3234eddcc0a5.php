<div>
    <?php if($textoPrimo): ?> <p><?php echo e($textoPrimo); ?></p> <?php endif; ?>
    <?php if($textoBisiesto): ?> <p><?php echo e($textoBisiesto); ?></p> <?php endif; ?>
    <?php if($textoFibonacci): ?> <p><?php echo e($textoFibonacci); ?></p> <?php endif; ?>
    <?php if($textoUsuario): ?> <p><?php echo e($textoUsuario); ?></p> <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\resources\views/resultados.blade.php ENDPATH**/ ?>