<div>
    <?php echo e($esPrimo); ?>

</div>
<?php /**PATH C:\wamp64\www\resources\views/resultadoejercicio1.blade.php ENDPATH**/ ?>