<form action="<?php echo e(route("datos")); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Número: </label>
    <input type="number" name="numero" id=""><br>

    <label>Fecha (dd-mm-aaaa):</label>
    <input type="text" name="fecha" id=""><br>

    <label>Cantidad elementos Fibonacci</label>
    <input type="number" name="cantidad" id=""><br>

    <label>Email:</label>
    <input type="email" name="email" id=""><br>

    <label>Contraseña:</label>
    <input type="password" name="password" id=""><br><br>

    <button type="submit">Enviar</button>
</form><?php /**PATH C:\xampp\htdocs\resources\views/formulario.blade.php ENDPATH**/ ?>