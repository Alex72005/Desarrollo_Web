<div>
    @if($textoPrimo) <p>{{ $textoPrimo }}</p> @endif
    @if($textoBisiesto) <p>{{ $textoBisiesto }}</p> @endif
    @if($textoFibonacci) <p>{{ $textoFibonacci }}</p> @endif
    @if($textoUsuario) <p>{{ $textoUsuario }}</p> @endif
</div>
