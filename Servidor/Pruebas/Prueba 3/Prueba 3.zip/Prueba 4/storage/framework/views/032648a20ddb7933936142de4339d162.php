<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Editar Hermandad</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        body{
            margin: 50px
        }
    </style>
</head>
<body>
    <div class="w-full max-w-xs">
        <h1>Actualizar Reserva</h1>
        <form action="<?php echo e(route("reserva_actualizar")); ?>" method="POST" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <div class="mb-4">
                <input type="hidden" name="id" value="<?php echo e($reserva->id); ?>">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Fecha
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="date" placeholder="Reserva" name="fecha" value="<?php echo e($reserva->fecha); ?>">

                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Hora
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="time" placeholder="Reserva" name="hora" value="<?php echo e($reserva->hora); ?>">

                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Email
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="email" placeholder="Reserva" name="email" value="<?php echo e($reserva->email); ?>">
                
                
                <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
                    Comensales
                </label>
                <input
                    class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    id="username" type="number" placeholder="Reserva" name="comensales" value="<?php echo e($reserva->comensales); ?>">
            </div>
            <div class="flex items-center justify-between">
                <button
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit">
                    Actualizar
                </button>
            </div>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\resources\views/editarReserva.blade.php ENDPATH**/ ?>