<div id="enrique">
    <?php echo e($password); ?>

    <?php echo e($email); ?>

</div>

<?php echo app('Illuminate\Foundation\Vite')("resources/js/prueba.js"); ?>
<?php /**PATH C:\xampp\htdocs\resources\views/enrique.blade.php ENDPATH**/ ?>