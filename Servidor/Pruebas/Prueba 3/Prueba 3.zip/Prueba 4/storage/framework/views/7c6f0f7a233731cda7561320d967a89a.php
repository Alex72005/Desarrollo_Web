<form action="<?php echo e(route("datos")); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input name="email" type="text">
    <input name="password" type="password">
    <button type="sumbit">Enviar</button>
</form>

<div>
    <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($c->nombre); ?></p>
        <p><?php echo e($c->pepito->nombre); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php /**PATH C:\xampp\htdocs\resources\views/centros.blade.php ENDPATH**/ ?>