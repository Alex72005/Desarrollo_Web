<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReservaController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/prueba', [ReservaController::class, "index"])->name("reserva_mostrar");
Route::post('/reserva', [ReservaController::class, "create"])->name("reserva_crear");
Route::delete('/reserva', [ReservaController::class, "destroy"])->name("reserva_borrar");
Route::put('/reserva', [ReservaController::class, "edit"])->name("reserva_editar");
Route::put('/reserva/actualizar', [ReservaController::class, "update"])->name("reserva_actualizar");