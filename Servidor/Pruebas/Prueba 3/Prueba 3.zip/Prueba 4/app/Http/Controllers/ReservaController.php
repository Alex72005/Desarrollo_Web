<?php

namespace App\Http\Controllers;

use App\Models\Reserva;
use Illuminate\Http\Request;

class ReservaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $reservas = Reserva::all();
        return view('prueba', ['reservas' => $reservas]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $h = new Reserva();
        $h->fecha = $request["fecha"];
        $h->hora = $request["hora"];
        $h->email = $request["email"];
        $h->comensales = $request["comensales"];
        $h->save();

        return redirect()->route("reserva_mostrar");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        $idReserva = $request["reservas"];
        $datosReserva = Reserva::where("id", $idReserva)->first();
        return view("editarReserva", ["reserva" => $datosReserva]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $reservaAActualizar = Reserva::where("id", $request["id"])->first();
        $reservaAActualizar->fecha = $request["fecha"];
        $reservaAActualizar->hora = $request["hora"];
        $reservaAActualizar->email = $request["email"];
        $reservaAActualizar->comensales = $request["comensales"];
        $reservaAActualizar->save();

        return redirect()->route("reserva_mostrar");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $reservaABorrar = Reserva::where("id", $request["reservas"])->delete();
        return redirect()->route("reserva_mostrar");
    }
}
