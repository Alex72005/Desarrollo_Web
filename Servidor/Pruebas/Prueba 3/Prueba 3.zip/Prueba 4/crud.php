<?php
$servidor = "localhost";
$usuario = "root";
$contr = "";
$baseDatos = "moriles2";

$conn = mysqli_connect($servidor, $usuario, $contr, $baseDatos);

if (!$conn) {
    die("conexion fallida" . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') { 

    if (isset($_POST['_method']) && $_POST['_method'] === 'put') { 
        $email = $_POST['email'];
        $opcion = $_POST['opciones'];
        $nuevo = $_POST['datoNuevo'];

        $consulta = "UPDATE reservas SET $opcion = '$nuevo' WHERE email = '$email'";
        $ejecutarConsulta = mysqli_query($conn, $consulta);
    } else if (isset($_POST['_method']) && $_POST['_method'] === 'delete') { 
        $email = $_POST['email'];
        $consulta = "DELETE FROM reservas WHERE email = '$email'";
        $ejecutarConsulta = mysqli_query($conn, $consulta);
    } else { 
        $fecha = $_POST['fecha'];
        $hora = $_POST['hora'];
        $email = $_POST['email'];
        $comensales = $_POST['comensales'];

        $insertar = "INSERT INTO reservas (fecha, hora, email, comensales) VALUES ('$fecha', '$hora', '$email', '$comensales')";
        $ejecutarConsulta = mysqli_query($conn, $insertar);
    }
}
else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $consulta = "SELECT * FROM reservas ORDER BY id";
    $ejecutarConsulta = mysqli_query($conn, $consulta);
    if (mysqli_num_rows($ejecutarConsulta) > 0) { 
        $fila = mysqli_fetch_assoc($ejecutarConsulta);
        echo "fecha: " . $fila['fecha'] . " hora: " . $fila['hora'] . " email: " . $fila['email'] . " comensales: " . $fila['comensales'];
    }
}
