<form action="<?php echo e(route("datos")); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="importe" id=""><br>
    <select name="desde" id="">
        <option value="EUR">EUR</option>
        <option value="GBP">GBP</option>
        <option value="USD">USD</option>
    </select>

    <select name="a" id="">
        <option value="EUR">EUR</option>
        <option value="GBP">GBP</option>
        <option value="USD">USD</option>
    </select>
    
    <button type="submit">Convertir</button>
</form>

<br><br><br>
<?php /**PATH C:\xampp\htdocs\resources\views/formulario.blade.php ENDPATH**/ ?>