<div>
    <?php echo e($resultado); ?>

</div>
<?php /**PATH C:\xampp\htdocs\resources\views/resultados.blade.php ENDPATH**/ ?>