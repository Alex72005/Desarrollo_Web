<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormularioController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('formulario');
    }

    public function ejercicios(Request $request)
    {
        $importe = $request['importe'];
        $desde = $request['desde'];
        $a = $request['a'];

        $resultado = $this->convertidor($importe, $desde, $a);

        return view('resultados', ["resultado" => $resultado]);
    }

    public function convertidor(int $cantidad, string $desde, string $a)
    {
        if ($desde == "EUR") {
            if ($a == "USD") {
                $resultado = $cantidad * 1.08;
            } else {
                $resultado = $cantidad * 0.86;
            }
        } else if ($desde == "USD") {
            if ($a == "EUR") {
                $resultado = $cantidad * 0.92;
            } else {
                $resultado = $cantidad * 0.79;
            }
        } else if ($desde == "GBP") {
            if ($a == "EUR") {
                $resultado = $cantidad * 1.16;
            } else {
                $resultado = $cantidad * 1.26;
            }
        }

        return $resultado;
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
