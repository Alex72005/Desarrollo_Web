<?php

namespace App\Http\Controllers;

use App\Models\Evento;
use Exception;
use Illuminate\Http\Request;

class EventoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            if ((!isset($request['nombre'])) && (!isset($request['fechaInicio'])) && (!isset($request['fechaFin']))) {
                $evento = Evento::all();
                return response()->json($evento);
            } else if ((isset($request['nombre'])) && (!isset($request['fechaInicio'])) && (!isset($request['fechaFin']))) {
                $evento = Evento::where("nombre", $request['nombre'])->first();
                return response()->json($evento);
            } else if ((!isset($request['nombre'])) && (isset($request['fechaInicio'])) && (isset($request['fechaFin']))) {
                $evento = Evento::where("fecha", ">=", $request['fechaInicio'])->where("fecha", "<=", $request['fechaFin'])->get();
                return response()->json($evento);
            }
        } catch (Exception $e) {
            return response()->json([
                "error" => "No se mostraron todos los eventos",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $nombre = $request['nombre'];
            $ubicacion = $request['ubicacion'];
            $fecha = $request['fecha'];
            $hora = $request['hora'];

            $evento = new Evento();
            $evento->nombre = $nombre;
            $evento->ubicacion = $ubicacion;
            $evento->fecha = $fecha;
            $evento->hora = $hora;

            $evento->save();

            return response()->json([
                "success" => "El evento se ha creado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "error" => "El evento no se ha creado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $evento = Evento::whereId($id)->first();
            return response()->json($evento);
        } catch (Exception $e) {
            return response()->json([
                "error" => "No se mostraron el evento buscado",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $nombre = $request['nombre'];
            $ubicacion = $request['ubicacion'];
            $fecha = $request['fecha'];
            $hora = $request['hora'];

            $evento = Evento::whereId($id)->first();
            $evento->nombre = $nombre;
            $evento->ubicacion = $ubicacion;
            $evento->fecha = $fecha;
            $evento->hora = $hora;

            $evento->save();

            return response()->json([
                "success" => "El evento se ha actualizado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "error" => "El evento no se ha actualizado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $evento = Evento::whereId($id)->first();
            $evento->delete();
            return response()->json([
                "success" => "El evento se ha borrado correctamente"
            ]);
        } catch (Exception $e) {
            return response()->json([
                "success" => "El evento no se ha borrado correctamente",
                "mensaje" => $e->getMessage()
            ]);
        }
    }
}
