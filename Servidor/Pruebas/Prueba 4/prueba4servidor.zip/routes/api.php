<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventoController;
use App\Http\Controllers\ClinicaController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('/eventos', [EventoController::class, 'index']);
Route::post('/eventos', [EventoController::class, 'store']);
Route::put('/eventos/edit/{id}', [EventoController::class, 'update']);
Route::delete('/eventos/delete/{id}', [EventoController::class, 'destroy']);
Route::get('/eventos/show/{id}', [EventoController::class, 'show']);

// Route::get('/eventos/{nombre}', [EventoController::class, 'index']);
// Route::get('/eventos/{fechaInicio}&{fechaFin}', [EventoController::class, 'index']);