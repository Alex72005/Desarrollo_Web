<?php

use App\Http\Controllers\EventoController;
use App\Http\Controllers\ReservaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::apiResource("eventos", EventoController::class);

Route::get("/palabras_prohibidas", [EventoController::class, "get_palabras_prohibidas"]);

Route::post("/reservas", [ReservaController::class, "store"]);