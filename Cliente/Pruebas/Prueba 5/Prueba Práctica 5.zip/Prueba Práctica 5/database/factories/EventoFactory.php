<?php

namespace Database\Factories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Evento>
 */
class EventoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $hora = fake()->time('H:i');
        return [
            
            "nombre" =>str_replace(' ', '', substr(fake()->company(),0,10)),
            "ubicacion" =>fake()->address(),
            "fecha" => now(),
            "hora_inicio" => $hora,
            "hora_fin" => Carbon::parse($hora)->addHour(), 
            "capacidad" => "8"
        ];
    }
}
