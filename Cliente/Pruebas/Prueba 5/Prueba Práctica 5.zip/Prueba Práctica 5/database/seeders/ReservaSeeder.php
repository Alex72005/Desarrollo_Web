<?php

namespace Database\Seeders;

use App\Models\Reserva;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class ReservaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $reserva = new Reserva(); 
        $reserva->evento_id = 1; 
        $reserva->user_id = 1; 
        $reserva->save();

        $reserva = new Reserva(); 
        $reserva->evento_id = 2; 
        $reserva->user_id = 2; 
        $reserva->save();

        $reserva = new Reserva(); 
        $reserva->evento_id = 3; 
        $reserva->user_id = 3; 
        $reserva->save();
    }
}
