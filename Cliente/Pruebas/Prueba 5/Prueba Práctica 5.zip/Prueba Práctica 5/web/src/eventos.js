
// ============================================
// CONFIGURACIÓN DE LA API
// ============================================
// Cambia esta URL por la de tu API real
const API_URL = 'http://localhost:80/public/api/eventos';

// ============================================
// ELEMENTOS DEL DOM
// ============================================
const form = document.querySelector('#evento-form');
const formTitle = document.querySelector('#form-title');
const cancelBtn = document.querySelector('#cancel-btn');
const eventosList = document.querySelector('#eventos-list');
const loader = document.querySelector('#loader');
const emptyMessage = document.querySelector('#empty-message');
const eventosContainer = document.querySelector('#eventos-container');
const toast = document.querySelector('#toast');

// ============================================
// FUNCIONES AUXILIARES
// ============================================

// Mostrar notificación toast
function mostrarToast(mensaje, tipo = 'success') {
    const colores = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        info: 'bg-blue-500'
    };

    toast.textContent = mensaje;
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg text-white font-medium z-50 ${colores[tipo]}`;
    toast.classList.remove('hidden');

    setTimeout(() => {
        toast.classList.add('hidden');
    }, 3000);
}

// Limpiar formulario
function limpiarFormulario() {
    form.reset();
    document.querySelector('#evento-id').value = '';
    formTitle.textContent = 'Agregar Evento';
    cancelBtn.classList.add('hidden');
}

// ============================================
// OPERACIONES CRUD CON FETCH
// ============================================

let todos = []
// 1. OBTENER TODOS LOS EVENTOS (READ)
async function obtenerEventos() {
    try {
        loader.classList.remove('hidden');
        eventosContainer.classList.add('hidden');
        emptyMessage.classList.add('hidden');

        const response = await fetch(API_URL, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const eventos = await response.json();
        todos = eventos.data
        mostrarEventos(eventos.data);

    } catch (error) {
        console.error('Error al obtener eventos:', error);
        mostrarToast('Error al cargar los eventos: ' + error.message, 'error');
        eventosContainer.classList.add('hidden');
        emptyMessage.classList.remove('hidden');
    } finally {
        loader.classList.add('hidden');
    }
}

// 2. CREAR EVENTO (CREATE)
async function crearEvento(eventoData) {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(eventoData)
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const nuevoEvento = await response.json();
        mostrarToast('Evento agregado exitosamente', 'success');
        limpiarFormulario();
        obtenerEventos();

        return nuevoEvento;

    } catch (error) {
        console.error('Error al crear evento:', error);
        mostrarToast('Error al agregar evento: ' + error.message, 'error');
        throw error;
    }
}

// 3. ACTUALIZAR EVENTO (UPDATE)
async function actualizarEvento(id, eventoData) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(eventoData)
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const eventoActualizado = await response.json();
        mostrarToast('Evento actualizado exitosamente', 'success');
        limpiarFormulario();
        obtenerEventos();

        return eventoActualizado;

    } catch (error) {
        console.error('Error al actualizar evento:', error);
        mostrarToast('Error al actualizar evento: ' + error.message, 'error');
        throw error;
    }
}

// 4. ELIMINAR EVENTO (DELETE)
async function eliminarEvento(id) {
    if (!confirm('¿Estás seguro de que quieres eliminar este evento?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        mostrarToast('Evento eliminado exitosamente', 'success');
        obtenerEventos();

    } catch (error) {
        console.error('Error al eliminar evento:', error);
        mostrarToast('Error al eliminar evento: ' + error.message, 'error');
    }
}

// ============================================
// FUNCIONES DE UI
// ============================================

// Mostrar eventos en la tabla
function mostrarEventos(eventos) {
    if (!eventos || eventos.length === 0) {
        eventosContainer.classList.add('hidden');
        emptyMessage.classList.remove('hidden');
        return;
    }

    eventosContainer.classList.remove('hidden');
    emptyMessage.classList.add('hidden');

    eventosList.innerHTML = eventos.map(evento => `
        <tr class="hover:bg-gray-50 transition-colors">
            <td class="px-4 py-3 text-sm text-gray-900">${evento.nombre}</td>
            <td class="px-4 py-3 text-sm text-gray-600">${evento.ubicacion ?? '----'}</td>
            <td class="px-4 py-3 text-sm text-gray-600">${evento.fecha}</td>
            <td class="px-4 py-3 text-sm text-gray-600">${evento.hora_inicio}</td>
            <td class="px-4 py-3 text-sm text-gray-600">${evento.hora_fin ?? '----'}</td>
            <td class="px-4 py-3 text-sm space-x-2">
                <button 
                    id="editarEvento" 
                    data-editar='${JSON.stringify(evento)}' 
                    class="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600 transition-colors text-xs font-medium"
                >
                    ✏️ Editar
                </button>
                <button 
                    id="eliminarEvento" 
                    data-eliminar='${evento.id}' 
                    class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 transition-colors text-xs font-medium"
                >
                    🗑️ Eliminar
                </button>
            </td>
        </tr>
    `).join('');

    // Cargar información evento al pulsar sobre Editar
    document.querySelectorAll('#editarEvento').forEach(element => {
        element.addEventListener('click', (e) => {
            const evento = JSON.parse(e.target.dataset.editar)
            editarEvento(evento)
        });
    });

    // Cargar información evento al pulsar sobre Eliminar
    document.querySelectorAll('#eliminarEvento').forEach(element => {
        element.addEventListener('click', (e) => {
            eliminarEvento(e.target.dataset.eliminar)
        });
    });
}

// Cargar datos del evento en el formulario para editar
function editarEvento(evento) {
    console.log(evento)
    document.querySelector('#evento-id').value = evento.id;
    document.querySelector('#nombre').value = evento.nombre;
    document.querySelector('#ubicacion').value = evento.ubicacion;
    document.querySelector('#fecha').value = evento.fecha;
    document.querySelector('#hora_inicio').value = evento.hora_inicio;
    document.querySelector('#hora_fin').value = evento.hora_fin;

    formTitle.textContent = 'Editar Evento';
    cancelBtn.classList.remove('hidden');

    // Scroll hacia el formulario
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ============================================
// EVENT LISTENERS
// ============================================

// Cargar eventos al pulsar sobre Actualizar
document.querySelector('#actualizar').addEventListener('click', () => {
    obtenerEventos();
});

// Submit del formulario
form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const eventoData = {
        nombre: document.querySelector('#nombre').value,
        ubicacion: document.querySelector('#ubicacion').value,
        fecha: document.querySelector('#fecha').value,
        hora_inicio: document.querySelector('#hora_inicio').value,
        hora_fin: document.querySelector('#hora_fin').value
    };

    const eventoId = document.querySelector('#evento-id').value;

    if (eventoId) {
        // Actualizar evento existente
        await actualizarEvento(eventoId, eventoData);
    } else {
        // Crear nuevo evento
        await crearEvento(eventoData);
    }
});

// Botón cancelar
cancelBtn.addEventListener('click', limpiarFormulario);

// ============================================
// INICIALIZACIÓN
// ============================================

// Cargar eventos al cargar la página
document.addEventListener('DOMContentLoaded', () => {
    obtenerEventos();
    obtenerPalabrasProhibidas();

});

const nombreCrear = document.querySelector("#nombre")
const errorNombre = document.querySelector("#error-nombre")
const ubicacionCrear = document.querySelector("#ubicacion")
const errorUbicacion = document.querySelector("#error-ubicacion")
const fechaCrear = document.querySelector("#fecha")
const errorFecha = document.querySelector("#error-fecha")
const hora_inicioCrear = document.querySelector("#hora_inicio")
const errorHora_inicio = document.querySelector("#error-hora-inicio")
const hora_finCrear = document.querySelector("#hora_fin")
const errorHora_fin = document.querySelector("#error-hora-fin")


async function obtenerPalabrasProhibidas() {
    try {
        const response = await fetch("http://localhost/public/api/palabras_prohibidas", {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }

        const peticion = await response.json();
        const arrayPalabras = peticion.data

        for (let categoria in arrayPalabras) {
            let arrayCategoria = arrayPalabras[categoria]
            arrayCategoria.forEach(p => {
                if (nombreCrear.value.includes(p)) {
                    errorNombre.textContent = "El nombre no puede contener palabras prohibidas"
                }
            })
        }

    } catch (error) {
        console.error('Error al obtener palabras prohibidas:', error);
    }
}

nombreCrear.addEventListener('keyup', () => {
    const nombre = nombreCrear.value

    if (nombre == "") {
        errorNombre.textContent = "El nombre es obligatorio"
    } else if (nombre.length < 3 || nombre.length > 10) {
        errorNombre.textContent = "El nombre debe tener entre 3 y 10 caracteres"
    } else if (nombre.includes(" ")) {
        errorNombre.textContent = "El nombre no puede tener espacios"
    } else {
        errorNombre.textContent = ""
    }

    obtenerPalabrasProhibidas()

})

ubicacionCrear.addEventListener('keyup', () => {    
    const ubicacion = ubicacionCrear.value

    if (ubicacion.length < 3 || ubicacion.length > 100) {
        errorUbicacion.textContent = "La ubicacion debe tener entre 3 y 100 caracteres"
    } else {
        errorUbicacion.textContent = " "
    }

})

fechaCrear.addEventListener('change', () => {
    const fechaInput = fechaCrear.value
    const fecha = new Date(fechaInput)
    const hoy = new Date()
    const nombre = nombreCrear.value

    if (!fechaInput) {
        return errorFecha.textContent = "La fecha es obligatoria"
    }

    if (hoy < fecha) {
        return errorFecha.textContent = "El evento no puede tener como fecha una fecha pasada"
    }

    todos.forEach(e => {
        if (e.fecha == fechaInput && e.nombre == nombre) {
            errorFecha.textContent = "No puede haber dos eventos con el mismo nombre en la misma fecha";
        } else {
            errorFecha.textContent = ""
        }
    })

})

hora_inicioCrear.addEventListener('change', validarHoras)
hora_finCrear.addEventListener('change', validarHoras)

function validarHoras() {
    const horaInicio = hora_inicioCrear.value
    const horaFin = hora_finCrear.value

    errorHora_inicio.textContent = "";
    errorHora_fin.textContent = "";

    if (!horaInicio) {
        return errorHora_inicio.textContent = "La hora inicio es obligatoria"
    }

    const fechaBase = '2025/11/27 ';

    const fechaHoraInicio = new Date(fechaBase + horaInicio);
    const fechaHoraFin = new Date(fechaBase + horaFin);

    if (fechaHoraInicio > fechaHoraFin) {
        errorHora_fin.textContent = "La hora de fin debe ser mayor que la hora de inicio";
    }
}
