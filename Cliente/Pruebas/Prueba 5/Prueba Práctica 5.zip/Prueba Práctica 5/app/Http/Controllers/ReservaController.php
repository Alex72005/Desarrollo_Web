<?php

namespace App\Http\Controllers;

use App\Models\Reserva;
use Exception;
use Illuminate\Http\Request;

class ReservaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }
    //un usuario solo puede tener reserva para 5 eventos
    //un evento no puede superar la capacidad del evento. 
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            
            $reserva = new Reserva();
            $reserva->evento_id = $request["evento_id"];
            $reserva->user_id = $request["user_id"];
            $reserva->save();

            return response()->json([
                'success' => true,
                'message' => 'reserva insertada correctamente',
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Se ha producido un error al insertar el evento',
                'errors' => $e->getMessage(),
            ], 404);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
