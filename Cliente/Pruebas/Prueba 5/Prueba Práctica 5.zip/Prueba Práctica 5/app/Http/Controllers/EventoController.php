<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Evento;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EventoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public static function validar()
    {
        $reglas = [
            'nombre' => 'required|string|min:3|max:10',
            'ubicacion' => 'nullable|string|min:3|max:100',
            'fecha' => 'required|date',
            'hora_inicio' => 'required',
            'hora_fin' => 'nullable'
        ];

        $mensajes = [
            'nombre.required' => 'El nombre es obligatorio',
            'nombre.min' => 'El nombre debe tener entre 3 y 10 caracteres',
            'nombre.max' => 'El nombre debe tener entre 3 y 10 caracteres',

            'fecha.required' => 'La fecha es obligatoria',
            'fecha.date' => 'La fecha debe ser válida',

            'hora_inicio.required' => 'La hora de inicio es obligatoria'
        ];

        return [$reglas, $mensajes];
    }

    // public static function validaciones()
    // {

    // }

    public function index(Request $request)
    {
        try {
            $eventos = Evento::select('*');

            if (isset($request["nombre"])) {
                $eventos = $eventos->where("nombre", $request["nombre"]);
            }

            if (isset($request["fechaInicio"]) && isset($request["fechaFinal"])) {
                $eventos = $eventos->where("fecha", ">", $request["fechaInicio"])
                    ->where("fecha", "<", $request["fechaFinal"]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Eventos obtenidos correctamente',
                'data' => $eventos->get(),
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Se ha producido un error al obtener los eventos',
                'errors' => $e->getMessage(),
            ], 404);
        }
    }

    public function palabrasProhibidas(String $nombre)
    {
        $todas = [
            'spam' => [
                'oferta',
                'descuento',
                'promoción',
                'gratis',
                'compra',
                'clic',
                'ahora',
                'oportunidad',
                'última',
                'gana',
                'dinero',
                'crédito',
                'finanzas',
                'ofertas',
                'venta',
                'exclusivo',
                'newsletter',
                'suscríbete',
            ],
            'ilegal' => [
                'cocaína',
                'metanfetamina',
                'marihuana',
                'heroína',
                'éxtasis',
                'crack',
                'pistola',
                'rifle',
                'escopeta',
                'cuchillo',
                'bomba',
                'explosivo',
                'droga',
                'arma',
                'ilegal',
                'casino',
                'apuesta',
                'juego',
            ],
            'falso' => [
                'falso',
                'mentira',
                'estafa',
                'fraude',
                'rumor',
                'engaño',
                'fake',
                'desinformación',
                'conspiración',
                'ilegítimo',
                'no autorizado',
            ],
            'marcas' => [
                'cocacola',
                'microsoft',
                'apple',
                'google',
                'facebook',
                'instagram',
                'twitter',
                'youtube',
                'amazon',
                'sony',
            ],
            'enganyo' => [
                'milagro',
                'oficial',
                'gratis',
                'garantizado',
                'exclusivo',
                'secreto',
                'hack',
                'estafa',
                'fraude',
            ]
        ];

        foreach ($todas as $categorias) {
            foreach ($categorias as $palabra) {
                if (str_contains($nombre, $palabra)) {
                    return true; 
                }
            }
        }

        return false; 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);

        try {
            if ($validacion->fails()) {
                return response()->json(["error" => $validacion->errors()->first()]);
            }

            //espacios
            for ($i = 0; $i < strlen($request["nombre"]); $i++) {
                if ($request["nombre"][$i] == " ") {
                    return response()->json(["error" => "El nombre no puede tener espacios"]);
                }
            }

            //fecha
            $hoy = Carbon::now();
            $fechaParseada = Carbon::parse($request->fecha);
            if ($hoy->lt($fechaParseada)) {
                return response()->json(["error" => "El evento no puede tener como fecha una fecha pasada"]);
            }

            //No puede haber dos nombres de evento iguales en la misma fecha
            $existe = Evento::where("nombre", $request->nombre)->where("fecha", $request->fecha)->exists();

            if ($existe) {
                return response()->json(["error" => "No puede haber dos eventos de nombre iguales con la misma fecha"]);
            }

            //hora
            $horaIni = '2025-11-28' . ($request->hora_inicio);
            $horaFin = '2025-11-28' . ($request->hora_fin);

            if ($horaIni > $horaFin) {
                return response()->json(["error" => "La hora de inicio debe ser menor a la hora de fin"]);
            }

            //palabrasProhibidas
            if ($this->palabrasProhibidas($request->nombre)) {
                return response()->json(["error" => "El nombre no puede contener las palabras prohibidas"]);
            }

            $evento = new Evento();
            $evento->nombre = $request["nombre"];
            $evento->ubicacion = $request["ubicacion"];
            $evento->fecha = $request["fecha"];
            $evento->hora_inicio = $request["hora_inicio"];
            $evento->hora_fin = $request["hora_fin"];
            $evento->capacidad = $request["capacidad"];
            $evento->save();

            return response()->json([
                'success' => true,
                'message' => 'Evento insertado correctamente',
                'data' => $evento,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Se ha producido un error al insertar el evento',
                'errors' => $e->getMessage(),
            ], 404);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validacion = Validator::make($request->all(), $this->validar()[0], $this->validar()[1]);

        try {
            if ($validacion->fails()) {
                return response()->json(["error" => $validacion->errors()->first()]);
            }

            //espacios
            for ($i = 0; $i < strlen($request["nombre"]); $i++) {
                if ($request["nombre"][$i] == " ") {
                    return response()->json(["error" => "El nombre no puede tener espacios"]);
                }
            }

            //fecha
            $hoy = Carbon::now();
            $fechaParseada = Carbon::parse($request->fecha);
            if ($hoy->lt($fechaParseada)) {
                return response()->json(["error" => "El evento no puede tener como fecha una fecha pasada"]);
            }

            //No puede haber dos nombres de evento iguales en la misma fecha
            $existe = Evento::where("nombre", $request->nombre)->where("fecha", $request->fecha)->exists();

            if ($existe) {
                return response()->json(["error" => "No puede haber dos eventos de nombre iguales con la misma fecha"]);
            }

            //hora
            $horaIni = '2025-11-28' . ($request->hora_inicio);
            $horaFin = '2025-11-28' . ($request->hora_fin);

            if ($horaIni > $horaFin) {
                return response()->json(["error" => "La hora de inicio debe ser menor a la hora de fin"]);
            }

            $evento = Evento::find($id);
            $evento->nombre = $request["nombre"];
            $evento->ubicacion = $request["ubicacion"];
            $evento->fecha = $request["fecha"];
            $evento->hora_inicio = $request["hora_inicio"];
            $evento->hora_fin = $request["hora_fin"];
            $evento->save();

            return response()->json([
                'success' => true,
                'message' => 'Evento actualizado correctamente',
                'data' => $evento,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Se ha producido un error al actualizar el evento',
                'errors' => $e->getMessage(),
            ], 404);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            Evento::find($id)->delete();

            return response()->json([
                'success' => true,
                'message' => 'Evento borrado correctamente',
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Se ha producido un error al borrar el evento',
                'errors' => $e->getMessage(),
            ], 404);
        }
    }

    /**
     * Devuelve uan serie de palabras prohibidas
     */
    public function get_palabras_prohibidas()
    {
        return response()->json([
            'success' => true,
            'message' => 'Se han obtenido las palabras prohibidas correctamente',
            'data' => [
                'spam' => [
                    'oferta',
                    'descuento',
                    'promoción',
                    'gratis',
                    'compra',
                    'clic',
                    'ahora',
                    'oportunidad',
                    'última',
                    'gana',
                    'dinero',
                    'crédito',
                    'finanzas',
                    'ofertas',
                    'venta',
                    'exclusivo',
                    'newsletter',
                    'suscríbete',
                ],
                'ilegal' => [
                    'cocaína',
                    'metanfetamina',
                    'marihuana',
                    'heroína',
                    'éxtasis',
                    'crack',
                    'pistola',
                    'rifle',
                    'escopeta',
                    'cuchillo',
                    'bomba',
                    'explosivo',
                    'droga',
                    'arma',
                    'ilegal',
                    'casino',
                    'apuesta',
                    'juego',
                ],
                'falso' => [
                    'falso',
                    'mentira',
                    'estafa',
                    'fraude',
                    'rumor',
                    'engaño',
                    'fake',
                    'desinformación',
                    'conspiración',
                    'ilegítimo',
                    'no autorizado',
                ],
                'marcas' => [
                    'cocacola',
                    'microsoft',
                    'apple',
                    'google',
                    'facebook',
                    'instagram',
                    'twitter',
                    'youtube',
                    'amazon',
                    'sony',
                ],
                'enganyo' => [
                    'milagro',
                    'oficial',
                    'gratis',
                    'garantizado',
                    'exclusivo',
                    'secreto',
                    'hack',
                    'estafa',
                    'fraude',
                ]
            ]
        ]);
    }
}
