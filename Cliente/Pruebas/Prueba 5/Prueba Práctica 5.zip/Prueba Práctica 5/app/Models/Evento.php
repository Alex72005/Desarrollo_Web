<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Evento extends Model
{

    use HasFactory;

    protected $table = "eventos";

    protected $fillable = [
        'nombre',
        'ubicacion',
        'fecha',
        "hora_inicio",
        "hora_fin",
        "capacidad"
    ];
}
